function startConfetti() {
    const confettiSettings = { 
        target: 'confetti-canvas',
        max: 200,
        size: 1.5,
        animate: true,
        props: ['circle', 'square', 'triangle', 'line'],
        colors: [
            [255, 107, 139],  // --primary
            [255, 179, 198],  // --secondary
            [255, 143, 163],  // --accent
            [201, 24, 74]     // --dark
        ],
        clock: 30,
        rotate: true,
        start_from_edge: true,
        respawn: true,
        width: window.innerWidth,
        height: window.innerHeight
    };
    
    const confetti = new ConfettiGenerator(confettiSettings);
    confetti.render();
    
    // Stop confetti after 10 seconds
    setTimeout(() => {
        confetti.clear();
    }, 10000);
}

// Create canvas for confetti if not exists
if (!document.getElementById('confetti-canvas')) {
    const canvas = document.createElement('canvas');
    canvas.id = 'confetti-canvas';
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.pointerEvents = 'none';
    canvas.style.zIndex = '1000';
    document.body.appendChild(canvas);
}