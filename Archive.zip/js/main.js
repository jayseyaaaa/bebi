// Calculate and continuously update time together from April 22, 2024
function updateTimeTogether() {
    const startDate = new Date('2024-04-22T00:00:00');
    const now = new Date();
    const diffTime = now - startDate;
    
    // Calculate time components
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffTime % (1000 * 60 * 60)) / (1000 * 60));
    const diffSeconds = Math.floor((diffTime % (1000 * 60)) / 1000);
    
    // Update display
    document.getElementById('daysTogether').textContent = diffDays;
    document.getElementById('hoursTogether').textContent = diffHours;
    document.getElementById('minutesTogether').textContent = diffMinutes;
    document.getElementById('secondsTogether').textContent = diffSeconds;
    
    // Update every second
    setTimeout(updateTimeTogether, 1000);
}

document.addEventListener('DOMContentLoaded', function() {
    updateTimeTogether(); // Start the counter
    
    // Create floating hearts
    createHearts();
    
    // Surprise button functionality
    const surpriseBtn = document.getElementById('surpriseBtn');
    const birthdayAudio = document.getElementById('birthdayAudio');
    
    surpriseBtn.addEventListener('click', function() {
        // Play birthday song
        birthdayAudio.play().catch(e => console.log("Audio play failed:", e));
        
        // Trigger confetti
        startConfetti();
        
        // Create more hearts
        for (let i = 0; i < 20; i++) {
            setTimeout(createHeart, i * 100);
        }
        
        // Change button text and style
        surpriseBtn.innerHTML = '<i class="fas fa-heart"></i> I Love You!';
        surpriseBtn.style.background = 'linear-gradient(45deg, #c9184a, #ff6b8b)';
        surpriseBtn.classList.add('celebrating');
    });
    
    function createHearts() {
        const heartCount = 15;
        for (let i = 0; i < heartCount; i++) {
            setTimeout(() => createHeart(), i * 300);
        }
    }
    
    function createHeart() {
        const heartsContainer = document.createElement('div');
        heartsContainer.className = 'hearts-container';
        document.body.appendChild(heartsContainer);
        
        const heart = document.createElement('div');
        heart.innerHTML = '❤';
        heart.classList.add('heart');
        heart.style.left = Math.random() * 100 + 'vw';
        heart.style.fontSize = (Math.random() * 20 + 10) + 'px';
        heart.style.animationDuration = (Math.random() * 3 + 4) + 's';
        
        heartsContainer.appendChild(heart);
        
        setTimeout(() => {
            heart.remove();
            heartsContainer.remove();
        }, 6000);
    }
    
    // Photo frame interactive effect
    const photoFrame = document.querySelector('.photo-frame');
    if (photoFrame) {
        photoFrame.addEventListener('mousemove', (e) => {
            const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
            const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
            photoFrame.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
        });
        
        photoFrame.addEventListener('mouseleave', () => {
            photoFrame.style.transform = 'rotateY(0deg) rotateX(0deg)';
        });
    }
});

function startConfetti() {
    confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#ff6b8b', '#ffb3c6', '#ff8fa3', '#c9184a']
    });
    
    const duration = 3000;
    const end = Date.now() + duration;

    (function frame() {
        confetti({
            particleCount: 50,
            angle: 60,
            spread: 55,
            origin: { x: 0 },
            colors: ['#ff6b8b', '#ffb3c6']
        });
        
        confetti({
            particleCount: 50,
            angle: 120,
            spread: 55,
            origin: { x: 1 },
            colors: ['#ff8fa3', '#c9184a']
        });

        if (Date.now() < end) {
            requestAnimationFrame(frame);
        }
    }());
}